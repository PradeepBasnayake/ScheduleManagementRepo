package com; 
import java.sql.*; 
public class schedule 
{ 
private Connection connect() 
 { 
		 Connection con = null; 
		 try
		 { 
			 Class.forName("com.mysql.jdbc.Driver"); 
			 con = 
			 DriverManager.getConnection( 
			 "jdbc:mysql://127.0.0.1:3306/schedule", "root", "12345"); 
		 } 
		 catch (Exception e) 
		 { 
			 e.printStackTrace(); 
		 } 
		 return con; 
	 } 


	public String readSchedule() 
	{ 
		 String output = ""; 
		 try
		 { 
		 Connection con = connect(); 
		 if (con == null) 
		 { 
		 return "Error while connecting to the database for reading."; 
		 } 
		 // Prepare the html table to be displayed
		 output = "<table border='1'><tr><th>group</th> "
		 		+ "<th>date</th><th>period</th>"
				 + "<th>area</th> "
				 + "<th>Update</th><th>Remove</th></tr>"; 
		 String query = "select * from schedule"; 
		 Statement stmt = con.createStatement(); 
		 ResultSet rs = stmt.executeQuery(query); 
		 
		 // iterate through the rows in the result set
		 while (rs.next()) 
		 { 
			 String schID = Integer.toString(rs.getInt("schID")); 
			 String group = rs.getString("group"); 
			
			 String date = rs.getString("date"); 
			 String period = rs.getString("period"); 
			 String area = rs.getString("area"); 
			 
			 // Add into the html table
			 output += "<tr><td><input id='hidschIDUpdate' "
					+ "name='hidschIDUpdate' "
					+ " type='hidden' value='" + schID
			 + "'>" + group + "</td>"; 
			 output += "<td>" + date + "</td>"; 
			 output += "<td>" + period + "</td>"; 
			 output += "<td>" + area + "</td>"; 
			 
			 // buttons
			output += "<td><input name='btnUpdate' "
					+ "type='button' value='Update' "
					+ " class='btnUpdate btn btn-secondary'></td>"
					+ "<td><input name='btnRemove' "
					+ "type='button' value='Remove' "
					+ "class='btnRemove btn btn-danger' "
					+ "data-schID='"
			 + schID + "'>" + "</td></tr>"; 
		 } 
		 con.close(); 
		 
		 // Complete the html table
		 output += "</table>"; 
		 } 
		 catch (Exception e) 
		 { 
		 output = "Error while reading the schedules."; 
		 System.err.println(e.getMessage()); 
		 } 
		 return output; 
	 } 
	
	
	public String insertSchedule(String group, String date, 
	 String period, String area) 
	 { 
		 String output = ""; 
		 try
		 { 
				 Connection con = connect(); 
				 if (con == null) 
			 { 
					 return "Error while connecting to the database for inserting."; 
			 } 
			 // create a prepared statement
			 String query = " insert into schedule ('schID','group','date','period','area')" + " values (?, ?, ?, ?, ?)"; 
			 
			 PreparedStatement preparedStmt = con.prepareStatement(query); 
			 // binding values
			 preparedStmt.setInt(1, 0); 
			 preparedStmt.setString(2, group); 
			 preparedStmt.setString(3, date); 
			 preparedStmt.setString(4, period); 
			 preparedStmt.setString(5, area); 
			 
			 // execute the statement
			 preparedStmt.execute(); 
			 con.close(); 
			 String newSchedule = readSchedule(); 
			 output = "{\"status\":\"success\", \"data\": \"" + 
			 newSchedule + "\"}"; 
			 
		  }
		 
		 catch (Exception e) 
		 { 
			 
			 output = "{\"status\":\"error\", \"data\": \"Error while inserting the Schedule.\"}"; 
			 System.err.println(e.getMessage()); 
			 
		 } 
		 
		 return output; 
	  } 
	
	
	public String updateSchedule(String schID, String group, String date, 
	 String period, String area) 
	{ 
		 String output = ""; 
		 try
		 { 
				 Connection con = connect(); 
				 if (con == null) 
			 { 
					 
				return "Error while connecting to the database for updating."; 
			 } 
				 
				 
			 // create a prepared statement
			 String query = "UPDATE schedule SET group=?,date=?,period=?,area=? WHERE schID=?"; 
			 PreparedStatement preparedStmt = con.prepareStatement(query); 
			 
			 // binding values
			 preparedStmt.setString(1, group); 
			 preparedStmt.setString(2, date); 
			 preparedStmt.setString(3, period); 
			 preparedStmt.setString(4, area); 
			 preparedStmt.setInt(5, Integer.parseInt(schID)); 
			 
			 // execute the statement
			 preparedStmt.execute(); 
			 con.close(); 
			 String newSchedule = readSchedule(); 
			 output = "{\"status\":\"success\", \"data\": \"" + 
			 newSchedule + "\"}"; 
		 }
		 
		 catch (Exception e) 
		 { 
			 output = "{\"status\":\"error\", \"data\": \"Error while updating the schedule.\"}"; 
			 System.err.println(e.getMessage()); 
			 
		 } 
		 	return output; 
		 } 
	
	
	
	public String deleteSchedule(String schID) 
	{ 
		 String output = ""; 
		 try
		 { 
			 Connection con = connect(); 
			 if (con == null) 
		 { 
				 
			return "Error while connecting to the database for deleting."; 
		 } 
			 
		 // create a prepared statement
			 
		 String query = "delete from schedule where schID=?"; 
		 PreparedStatement preparedStmt = con.prepareStatement(query); 
		 
		 // binding values
		 preparedStmt.setInt(1, Integer.parseInt(schID)); 
		 
		 // execute the statement
		 preparedStmt.execute(); 
		 con.close(); 
		 String newSchedule = readSchedule(); 
		 output = "{\"status\":\"success\", \"data\": \"" + 
		 newSchedule + "\"}"; 
		 
		 } 
		 	catch (Exception e) 
		 { 
			 output = "{\"status\":\"error\", \"data\": \"Error while deleting the schedule.\"}"; 
			 System.err.println(e.getMessage()); 
		 } 
		 
		 return output; 
		 } 
}
