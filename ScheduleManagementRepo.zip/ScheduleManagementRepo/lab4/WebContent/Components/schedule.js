$(document).ready(function()
{
	if ($("#alertSuccess").text().trim() == "")
	 {
	 $("#alertSuccess").hide();
	 }
	 $("#alertError").hide();
});



 // SAVE ============================================
   
$(document).on("click", "#btnSave", function(event)
	{
		
		// Clear alerts---------------------
		
		 $("#alertSuccess").text("");
		 $("#alertSuccess").hide();
		 $("#alertError").text("");
		 $("#alertError").hide();
		 
		// Form validation-------------------
	
		var status = validateScheduleForm();
		if (status != true)
	  {
		 $("#alertError").text(status);
		 $("#alertError").show();
		 return;
	   }
	
		
	var type = ($("#hidschIDSave").val() == "") ? "POST" : "PUT";
	
	$.ajax( 
			{ 
				 url : "scheduleAPI", 
				 type : type, 
				 data : $("#formschedule").serialize(), 
				 dataType : "text", 
				 complete : function(response, status) 
			 { 
				 onItemSaveComplete(response.responseText, status); 
			 } 
		});
		
	});
	
	
	
	//schedule save comple function
	

	function onScheduleSaveComplete(response, status) 
	{ 
	  if (status == "success") 
	   { 
				 var resultSet = JSON.parse(response); 
				 
				 if (resultSet.status.trim() == "success") 
				 
				 { 
					 $("#alertSuccess").text("Successfully saved."); 
					 $("#alertSuccess").show(); 
					 $("#divScheduleGrid").html(resultSet.data); 
					 
				 } else if (resultSet.status.trim() == "error") 
				 
				 { 
					 $("#alertError").text(resultSet.data); 
					 $("#alertError").show();
					  
				 } 
		 
		 } else if (status == "error") 
		 
		 { 
			 $("#alertError").text("Error while saving."); 
			 $("#alertError").show(); 
			 
		 } else
		 
		 { 
			 $("#alertError").text("Unknown error while saving.."); 
			 $("#alertError").show(); 
			 
		 } 
		
	
		 $("#hidschIDSave").val(""); 
		 $("#formSchedule")[0].reset(); 
	}
	

	
	
// update
	
	$(document).on("click", ".btnUpdate", function(event) 
	{ 
		 $("#hidschIDSave").val($(this).data("schID")); 
		 $("#group").val($(this).closest("tr").find('td:eq(0)').text()); 
		 $("#date").val($(this).closest("tr").find('td:eq(1)').text()); 
		 $("#period").val($(this).closest("tr").find('td:eq(2)').text()); 
		 $("#area").val($(this).closest("tr").find('td:eq(3)').text()); 
	});
	
	
	
//delete
	
$(document).on("click", ".btnRemove", function(event) 
	{ 
		 $.ajax( 
			 { 
					 url : "scheduleAPI", 
					 type : "DELETE", 
					 data : "schID=" + $(this).data("schid"),
					 dataType : "text", 
					 complete : function(response, status) 
				 { 
			     onScheduleDeleteComplete(response.responseText, status); 
			     } 
		 }); 
	});
	


//deletecompletion

function onScheduleDeleteComplete(response, status) 
{ 
	  if (status == "success") 
	 { 
		 var resultSet = JSON.parse(response); 
		 
			 if (resultSet.status.trim() == "success") 
				 { 
					 $("#alertSuccess").text("Successfully deleted."); 
					 $("#alertSuccess").show(); 
					 
					 $("#divScheduleGrid").html(resultSet.data); 
			 } else if (resultSet.status.trim() == "error") 
				 
			 { 
				 $("#alertError").text(resultSet.data); 
				 $("#alertError").show(); 
			 } 
			 
	} else if (status == "error") 
			 
	{ 
	     $("#alertError").text("Error while deleting."); 
		 $("#alertError").show(); 
	} else
			 
	 { 
	     $("#alertError").text("Unknown error while deleting.."); 
		 $("#alertError").show(); 
	 } 
		
		
	}	
		
	// CLIENT-MODEL================================================================
	
	function validateScheduleForm()
	{
	
	// group
	
	if ($("#group").val().trim() == "")
	 {
		 return "Insert group.";
	 }
	// date
	
	if ($("#date").val().trim() == "")
	 {
	 	return "Insert date.";
	 }
	 
	 
	// period-------------------------------
	
	if ($("#period").val().trim() == "")
	 {
		 return "Insert period.";
	 }
	 
	 
	// DESCRIPTION------------------------
	
	if ($("#area").val().trim() == "")
	 {
	 	return "Insert Area.";
	 }
	return true;
	


}	

